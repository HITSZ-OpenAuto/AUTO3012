%% ����״̬�ı仯��
function vel = derivative(robotCurrentPose, v, w, sampleTime)

yaw = robotCurrentPose(3)+ w*sampleTime;
vel = [v*cos(yaw) v*sin(yaw) w]';

end