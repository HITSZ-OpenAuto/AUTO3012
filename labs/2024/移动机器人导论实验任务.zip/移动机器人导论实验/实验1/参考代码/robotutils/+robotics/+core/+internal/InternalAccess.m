classdef InternalAccess < handle
    %This class is for internal use only. It may be removed in the future.

    %INTERNALACCESS Subclasses of this class will gain internal access to
    %   certain class properties/methods in the shared_robotics component 

    %   Copyright 2016-2019 The MathWorks, Inc.

    %#codegen
end

