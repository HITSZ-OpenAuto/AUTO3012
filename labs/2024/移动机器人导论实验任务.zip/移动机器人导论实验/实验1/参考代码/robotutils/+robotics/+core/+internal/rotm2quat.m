function q = rotm2quat(R)
%This function is for internal use only and can be removed in the future.

%ROTM2QUAT Convert orthonormal rotation matrices to a unit-quaternion.
%
%   Q = rotm2quat(R) returns a unit-quaternion of the form q = [w, x, y, z] that
%   corresopnds to an orthonormal rotation matrix R. The function is internal
%   and intentionally skips validation for performance.
%
%   Examples:
%      quat = robotics.core.internal.rotm2quat(eul2rotm([0 pi, 0]));
%
%   References:
%       See
%       https://en.wikipedia.org/wiki/Rotation_formalisms_in_three_dimensions#Rotation_matrix_%E2%86%94_quaternion
%
% Copyright 2021 The MathWorks, Inc.

%#codegen

% win, xin, yin, zin can become negative due to numerical errors, hence,
% sqrt(in) will be complex, and thus we will use abs(in).
win = 1 + trace(R);
w = 0.5*sqrt(abs(win));
if w > sqrt(eps)
    m = 1/(4*w);

    x = m * (R(3,2) - R(2,3));
    y = m * (R(1,3) - R(3,1));
    z = m * (R(2,1) - R(1,2));
else
    xin = 1 + R(1,1) - R(2,2) - R(3,3);
    x = 0.5*sqrt(abs(xin));
    if x > sqrt(eps)
        m = 1/(4*x);
        y = m * (R(1,2) + R(2,1));
        z = m * (R(1,3) + R(3,1));
        w = m * (R(3,2) - R(2,3));
    else
        yin = 1 - R(1,1) + R(2,2) - R(3,3);
        y = 0.5*sqrt(abs(yin));
        if y > sqrt(eps)
            m = 1/(4*y);
            x = m * (R(2,1) + R(1,2));
            z = m * (R(3,2) + R(2,3));
            w = m * (R(1,3) - R(3,1));
        else
            zin = 1 - R(1,1) - R(2,2) + R(3,3);
            z = 0.5*sqrt(abs(zin));
            m = 1/(4*z);
            x = m * (R(1,3) + R(3,1));
            y = m * (R(3,2) + R(2,3));
            w = m * (R(2,1) - R(1,2));
        end
    end
end
q = [w x y z];
end
