% Rotation Representations and Utilities 
%
%   quaternion      - Create a quaternion
%   randrot         - Uniformly distributed random rotations    

% Copyright 2017-2022 The MathWorks, Inc.
