function name = matlabCodegenRedirect(~)
%This function is for internal use only. It may be removed in the future. 

%   Copyright 2018 The MathWorks, Inc.    

name = 'matlabshared.rotations.internal.coder.quaternioncg';
end
