function o = ctor(~,varargin)
%   This method is for internal use only. It may be removed in the future. 
%CTOR - call the constructor
%   Invoke the constructor. Typically called by the base class

%   Copyright 2018 The MathWorks, Inc.      

o = quaternion(varargin{:});
end
