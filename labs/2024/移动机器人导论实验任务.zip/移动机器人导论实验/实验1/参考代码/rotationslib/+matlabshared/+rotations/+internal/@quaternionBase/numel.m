function n = numel(obj)
%NUMEL Number of elements in a quaternion array

%   Copyright 2018 The MathWorks, Inc.    

%#codegen 

n = numel(obj.a);
end
