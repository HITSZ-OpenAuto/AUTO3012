function tf = isrow(obj)
%ISROW True if input is a row vector

%   Copyright 2018 The MathWorks, Inc.    

%#codegen 

tf = isrow(obj.a);
end
