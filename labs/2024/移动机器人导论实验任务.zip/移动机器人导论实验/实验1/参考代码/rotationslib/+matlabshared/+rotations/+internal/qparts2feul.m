function eout = qparts2feul(qa,qb,qc,qd,rot)
%   This function is for internal use only. It may be removed in the future.

%QPARTS2FEUL - Euler angles from quaternion parts

%   Copyright 2017 - 2021 The MathWorks, Inc.

%#codegen

%column-ize quaternion parts
qa = qa(:);
qb = qb(:);
qc = qc(:);
qd = qd(:);
the1 = ones(1, 'like', qa); % single(1) or double(1) as appropriate
the2 = 2*the1; % single(2) or double(2) as appropriate
a = zeros(size(qa), 'like', qa);
b = zeros(size(qb), 'like', qb);
c = zeros(size(qc), 'like', qc);

found = true;
switch upper(rot)
    case 'YZY'
        tmp = qa.^2.*the2 - the1 + qc.^2.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(0 + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = acos(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qb(ii),qd(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qc(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qb(ii).*the2 + qc(ii).*qd(ii).*the2),(qa(ii).*qd(ii).*the2 - qb(ii).*qc(ii).*the2));
                c(ii) = -atan2((qa(ii).*qb(ii).*the2 - qc(ii).*qd(ii).*the2),(qa(ii).*qd(ii).*the2 + qb(ii).*qc(ii).*the2));
            end
        end
    case 'YXY'
        tmp = qa.^2.*the2 - the1 + qc.^2.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(0 + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = acos(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = -2.*atan2(qd(ii),qb(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qc(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = -atan2((qa(ii).*qd(ii).*the2 - qb(ii).*qc(ii).*the2),(qa(ii).*qb(ii).*the2 + qc(ii).*qd(ii).*the2));
                c(ii) = atan2((qa(ii).*qd(ii).*the2 + qb(ii).*qc(ii).*the2),(qa(ii).*qb(ii).*the2 - qc(ii).*qd(ii).*the2));
            end
        end
    case 'ZYZ'
        tmp = qa.^2.*the2 - the1 + qd.^2.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(0 + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = acos(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = -2.*atan2(qb(ii),qc(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qd(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = -atan2((qa(ii).*qb(ii).*the2 - qc(ii).*qd(ii).*the2),(qa(ii).*qc(ii).*the2 + qb(ii).*qd(ii).*the2));
                c(ii) = atan2((qa(ii).*qb(ii).*the2 + qc(ii).*qd(ii).*the2),(qa(ii).*qc(ii).*the2 - qb(ii).*qd(ii).*the2));
            end
        end
    case 'ZXZ'
        tmp = qa.^2.*the2 - the1 + qd.^2.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(0 + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = acos(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qc(ii),qb(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qd(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qc(ii).*the2 + qb(ii).*qd(ii).*the2),(qa(ii).*qb(ii).*the2 - qc(ii).*qd(ii).*the2));
                c(ii) = -atan2((qa(ii).*qc(ii).*the2 - qb(ii).*qd(ii).*the2),(qa(ii).*qb(ii).*the2 + qc(ii).*qd(ii).*the2));
            end
        end
    case 'XYX'
        tmp = qa.^2.*the2 - the1 + qb.^2.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(0 + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = acos(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qd(ii),qc(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qd(ii).*the2 + qb(ii).*qc(ii).*the2),(qa(ii).*qc(ii).*the2 - qb(ii).*qd(ii).*the2));
                c(ii) = -atan2((qa(ii).*qd(ii).*the2 - qb(ii).*qc(ii).*the2),(qa(ii).*qc(ii).*the2 + qb(ii).*qd(ii).*the2));
            end
        end
    case 'XZX'
        tmp = qa.^2.*the2 - the1 + qb.^2.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(0 + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = acos(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = -2.*atan2(qc(ii),qd(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = -atan2((qa(ii).*qc(ii).*the2 - qb(ii).*qd(ii).*the2),(qa(ii).*qd(ii).*the2 + qb(ii).*qc(ii).*the2));
                c(ii) = atan2((qa(ii).*qc(ii).*the2 + qb(ii).*qd(ii).*the2),(qa(ii).*qd(ii).*the2 - qb(ii).*qc(ii).*the2));
            end
        end
    case 'XYZ'
        tmp = qa.*qc.*the2 + qb.*qd.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(0.5.*pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(-0.5.*pi + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = asin(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qb(ii).*the2 - qc(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qd(ii).^2.*the2));
                c(ii) = atan2((qa(ii).*qd(ii).*the2 - qb(ii).*qc(ii).*the2),(qa(ii).^2.*the2 - the1 + qb(ii).^2.*the2));
            end
        end
    case 'YZX'
        tmp = qa.*qd.*the2 + qb.*qc.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(0.5.*pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(-0.5.*pi + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = asin(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = -2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qc(ii).*the2 - qb(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qb(ii).^2.*the2));
                c(ii) = atan2((qa(ii).*qb(ii).*the2 - qc(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qc(ii).^2.*the2));
            end
        end
    case 'ZXY'
        tmp = qa.*qb.*the2 + qc.*qd.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(0.5.*pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(-0.5.*pi + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = asin(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qc(ii),qa(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = -2.*atan2(qc(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qd(ii).*the2 - qb(ii).*qc(ii).*the2),(qa(ii).^2.*the2 - the1 + qc(ii).^2.*the2));
                c(ii) = atan2((qa(ii).*qc(ii).*the2 - qb(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qd(ii).^2.*the2));
            end
        end
    case 'XZY'
        tmp = qb.*qc.*the2 - qa.*qd.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(0.5.*pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(-0.5.*pi + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = -asin(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qb(ii).*the2 + qc(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qc(ii).^2.*the2));
                c(ii) = atan2((qa(ii).*qc(ii).*the2 + qb(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qb(ii).^2.*the2));
            end
        end
    case 'ZYX'
        tmp = qb.*qd.*the2 - qa.*qc.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(0.5.*pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(-0.5.*pi + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = -asin(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = -2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qb(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qd(ii).*the2 + qb(ii).*qc(ii).*the2),(qa(ii).^2.*the2 - the1 + qb(ii).^2.*the2));
                c(ii) = atan2((qa(ii).*qb(ii).*the2 + qc(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qd(ii).^2.*the2));
            end
        end
    case 'YXZ'
        tmp = qc.*qd.*the2 - qa.*qb.*the2;
        tmp(tmp > the1) = the1;
        tmp(tmp < -the1) = -the1;
        tolA = cast(0.5.*pi - 10.*eps(the1), 'like', tmp);
        tolB = cast(-0.5.*pi + 10.*eps(the1), 'like', tmp);
        for ii=1:numel(tmp)
            b(ii) = -asin(tmp(ii));
            if b(ii) >=  tolA
                a(ii) = 2.*atan2(qc(ii),qa(ii));
                c(ii) = 0;
            elseif b(ii) <= tolB
                a(ii) = 2.*atan2(qc(ii),qa(ii));
                c(ii) = 0;
            else
                a(ii) = atan2((qa(ii).*qc(ii).*the2 + qb(ii).*qd(ii).*the2),(qa(ii).^2.*the2 - the1 + qd(ii).^2.*the2));
                c(ii) = atan2((qa(ii).*qd(ii).*the2 + qb(ii).*qc(ii).*the2),(qa(ii).^2.*the2 - the1 + qc(ii).^2.*the2));
            end
        end
    otherwise
        found = false;
        a = zeros(size(qa), 'like', qa);
        b = zeros(size(qa), 'like', qa);
        c = zeros(size(qa), 'like', qa);
end
coder.internal.assert(found, 'shared_rotations:quaternion:NoSeqConv', rot);
eout = [a b c];
end
