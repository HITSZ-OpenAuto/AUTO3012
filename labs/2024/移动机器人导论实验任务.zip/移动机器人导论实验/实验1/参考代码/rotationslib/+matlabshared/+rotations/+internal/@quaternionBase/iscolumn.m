function tf = iscolumn(obj)
%ISCOLUMN True if input is a column vector

%   Copyright 2018 The MathWorks, Inc.    

%#codegen 

tf = iscolumn(obj.a);
end
