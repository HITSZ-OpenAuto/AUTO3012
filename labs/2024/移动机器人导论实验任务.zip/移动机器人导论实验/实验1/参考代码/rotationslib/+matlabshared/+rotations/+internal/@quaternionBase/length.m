function l = length(obj)
%LENGTH Length of a quaternion vector

%   Copyright 2018 The MathWorks, Inc.    

%#codegen 

l = length(obj.a);
end
