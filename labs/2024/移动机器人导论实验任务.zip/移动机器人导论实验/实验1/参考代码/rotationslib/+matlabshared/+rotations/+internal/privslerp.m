function qo = privslerp(q1, q2, t)
%   This function is for internal use only. It may be removed in the future. 
%PRIVSLERP Slerp implementation, as a function

%   Copyright 2018-2021 The MathWorks, Inc.

%#codegen 

% Honor user request for implicit expansion
coder.internal.implicitExpansionBuiltin;

coder.internal.assert(isa(q1, 'quaternion'), ...
    'shared_rotations:quaternion:QuatExpectedArg', '1');
coder.internal.assert(isa(q2, 'quaternion'), ...
    'shared_rotations:quaternion:QuatExpectedArg', '2');
validateattributes(t, {'double', 'single'}, {'>=' 0, '<=', 1, ...
    'finite', 'nonnan', 'real', 'nonsparse'}, 'slerp', 't', 3);


% For codegen implicit expansion, ensure compatible dims, else throw a proper error.
quatAssertCompatibleDims(q1, q2);
quatAssertCompatibleDims(q2, t);
quatAssertCompatibleDims(t, q1);

% Normalize an expand
q1n = normalize(q1) .* ones(size(q2), 'like', q2);
q2n = normalize(q2) .* ones(size(q1), 'like', q1);

% Get parts
[a1, b1, c1, d1] = parts(q1n);
[a2, b2, c2, d2] = parts(q2n);

% Implement quaternion dot product, inline
dp = a1.*a2 + b1.*b2 + c1.*c2 + d1.*d2;

% Negative dot product, the quaternions aren't pointing the same way (one
% pos, one negative). Flip the second one. Sim and codegen path because 
% logical indexing on the rhs is a varsize operation which causes MATLAB
% Coder to error. The for-loop is also more efficient in the generated C
% code. 
if isempty(coder.target)
    dpidx = dp < 0;
    if any(dpidx(:))
        q2n(dpidx) = -q2n(dpidx);
        dp(dpidx) = -dp(dpidx);
    end
    dp(dp > 1) = 1;
else
    for ii=1:numel(dp)
        if dp(ii) < 0
            q2n(ii) = -q2n(ii);
            dp(ii) = -dp(ii);
        end
        if dp(ii) > 1
            dp(ii) = 1;
        end
    end
    
end
theta0 = acos(dp);

sinv = 1./sin(theta0);
qnumerator = q1n.*sin((1- t).*theta0) + q2n.*sin(t.*theta0);
qo =  qnumerator.* sinv;

% Fix up dp == 1 which causes NaN quaternions. This means the two
% quaternions are the same - just use the first. 
%
% If sinv is inf, qo is nan. But we can't look for nans in qo because they
% may have come in from q1 or q2 == nan at input. Instead find infs in
% sinv, then expand it to match size of qo, then put the expanded q1s where
% we found infs. 
infmap = isinf(sinv);
if any(infmap(:)) % Don't do this unless necessary
    infmapExpanded = infmap & true(size(qo)); % handle implicit expansion to size(qo)
    infmapExpandedNumeric = cast(infmapExpanded, classUnderlying(qo)); % same thing as above with 1s
    replaceval = q1 .* infmapExpandedNumeric; % an array with q1 everywhere there's an inf in infmapExpanded
    qo(infmapExpanded) = replaceval(infmapExpanded); % replace
end

qo = normalize(qo);
