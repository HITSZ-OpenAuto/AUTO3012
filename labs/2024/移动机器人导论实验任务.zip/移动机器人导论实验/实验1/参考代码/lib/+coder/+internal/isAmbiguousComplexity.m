function out = isAmbiguousComplexity()
%

%   Copyright 2014-2019 The MathWorks, Inc.
out = false;

