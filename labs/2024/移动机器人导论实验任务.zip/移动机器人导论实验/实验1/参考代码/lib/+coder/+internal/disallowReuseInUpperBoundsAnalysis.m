function disallowReuseInUpperBoundsAnalysis
%MATLAB Code Generation Private Function

%   Copyright 2021 The MathWorks, Inc.