function addDependentFile(~)
%MATLAB Code Generation Private Function

% MATLAB execution for Coder built-in function
% It adds a dependency on aFileName for incremental build.

%   Copyright 2020 The MathWorks, Inc.

end