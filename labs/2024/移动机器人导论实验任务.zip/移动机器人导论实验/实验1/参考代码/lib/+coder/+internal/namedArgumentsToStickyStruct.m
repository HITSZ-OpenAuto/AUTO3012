function namedargs = namedArgumentsToStickyStruct(namedargs)
% This file is for MATLAB execution only
% In code generation, converts input to a coder.internal.stickyStruct.
% In MATLAB, returns a normal struct.
