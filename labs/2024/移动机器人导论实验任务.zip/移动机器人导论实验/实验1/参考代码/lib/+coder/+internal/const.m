function out = const(varargin)
%

%   Copyright 2010-2019 The MathWorks, Inc.

  out = varargin{1};
end
