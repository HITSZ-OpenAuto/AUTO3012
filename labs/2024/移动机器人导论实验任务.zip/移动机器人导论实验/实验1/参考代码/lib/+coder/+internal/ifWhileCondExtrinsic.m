function y = ifWhileCondExtrinsic(x)
%MATLAB Code Generation Private Function

%   Helper for ifWhileCond to call extrinsically

%   Copyright 2015-2019 The MathWorks, Inc.
if x
    y = true;
else
    y = false;
end
