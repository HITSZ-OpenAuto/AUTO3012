function stringchk
%MATLAB Code Generation Private Function

%   Copyright 2013-2019 The MathWorks, Inc.
