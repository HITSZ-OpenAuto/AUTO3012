function out = isAmbiguousTypes()
%

%   Copyright 2014-2019 The MathWorks, Inc.
out = false;

