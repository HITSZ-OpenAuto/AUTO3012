function defer_inference(fcn_name, varargin)
%

%   Copyright 2011-2019 The MathWorks, Inc.

    feval(fcn_name, varargin{:});
end
