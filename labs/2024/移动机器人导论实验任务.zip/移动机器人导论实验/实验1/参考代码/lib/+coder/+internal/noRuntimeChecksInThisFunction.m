function noRuntimeChecksInThisFunction
%MATLAB Code Generation Private Function

%   Copyright 2016-2019 The MathWorks, Inc.
