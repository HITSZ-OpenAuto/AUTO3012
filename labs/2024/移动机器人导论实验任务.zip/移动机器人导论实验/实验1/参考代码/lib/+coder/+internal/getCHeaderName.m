function headerName = getCHeaderName(libHeader)
    % MATLAB Code Generation Private Function

    % This function is used for retrieving header name 
    % depending on the target of code generation.
    % The input argument must be a valid C header file name
    % without '.h' suffix.

    % Note that this function always returns
    % C header name either in C-syntax (example: <stdio.h>)
    % or in CPP-syntax (example: <cstdio>).

    % Please note that there is similiar function named
    % coder.internal.getCLibName to retrieve C/CPP library name.

    % Example usage:
    % To define a C file-stream object, instead of using old style,
    % use new approach by making use of these coder.internal functions.
    % Old approach:
    %   fd = coder.opaquePtr('FILE', 'NULL', 'HeaderFile', '<stdio.h>');
    % Recommended new approach:
    %   cHeader = coder.internal.getCHeaderName('stdio');
    %   cDataType = coder.internal.getCLibName('FILE');
    %   fd = coder.opaquePtr(cDataType, 'NULL', 'HeaderFile', cHeader);

    % Copyright 2022 The MathWorks, Inc.

    %#codegen

    if coder.target('C++') % CPP codegen
        headerName = ['<c' libHeader '>']; % example <cstdio>
    else % C codegen
        headerName = ['<', libHeader, '.h>']; % example <stdio.h>
    end
end
