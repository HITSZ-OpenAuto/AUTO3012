function y = timescale
%MATLAB Code Generation Private Function

%   Copyright 2018-2019 The MathWorks, Inc.

%#codegen
coder.inline('always');
y = 1e9;

%--------------------------------------------------------------------------
