function allowHalfInputs
%MATLAB Code Generation Private Function

%   Copyright 2018 The MathWorks, Inc.
