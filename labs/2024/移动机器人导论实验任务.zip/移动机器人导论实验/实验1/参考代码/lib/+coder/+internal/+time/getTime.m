function t = getTime()
%MATLAB Code Generation Private Function

%   Copyright 2018-2021 The MathWorks, Inc.

%#codegen
t = coder.internal.time.CoderTimeAPI.getTime();
