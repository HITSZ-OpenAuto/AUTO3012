function parallelRelax
%

%   Copyright 2019 The MathWorks, Inc.
