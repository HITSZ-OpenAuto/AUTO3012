function b = is_defined(x)
%

%   Copyright 2010-2019 The MathWorks, Inc.
coder.internal.allowHalfInputs;
b = ~isempty(x);

end
