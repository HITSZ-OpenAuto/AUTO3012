classdef ParenAssign
%

%   Copyright 2019-2022 The MathWorks, Inc.
%#codegen

  methods(Abstract)
    parenAssign(obj)
  end
end
