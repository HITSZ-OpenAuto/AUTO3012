function checkIndices(~, varargin)
%MATLAB Code Generation Private Function

%   Placeholder for modular indexing feature development

%   Copyright 2019 The MathWorks, Inc.
%#codegen

end