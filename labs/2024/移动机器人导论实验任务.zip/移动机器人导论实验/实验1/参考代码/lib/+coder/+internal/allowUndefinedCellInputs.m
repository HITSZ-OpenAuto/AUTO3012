function allowUndefinedCellInputs
%MATLAB Code Generation Private Function

%   Copyright 2014-2019 The MathWorks, Inc.
