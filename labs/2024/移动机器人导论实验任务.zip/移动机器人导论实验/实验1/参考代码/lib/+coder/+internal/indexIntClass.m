function y = indexIntClass()%
%

%   Copyright 2011-2019 The MathWorks, Inc.

y = 'int32';
end
