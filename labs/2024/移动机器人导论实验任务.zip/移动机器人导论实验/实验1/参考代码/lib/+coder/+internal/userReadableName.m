%MATLAB Code Generation Private Function

%   Copyright 2011-2019 The MathWorks, Inc.

% See comment for IBN_USER_READABLE_NAME in eml_builtin.hpp
%
function userReadableName(varargin)
end
