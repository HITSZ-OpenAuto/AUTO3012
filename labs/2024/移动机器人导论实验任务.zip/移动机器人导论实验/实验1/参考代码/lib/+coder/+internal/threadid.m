function y = threadid()%
%

%   Copyright 2013-2019 The MathWorks, Inc.

y = int32(0);
