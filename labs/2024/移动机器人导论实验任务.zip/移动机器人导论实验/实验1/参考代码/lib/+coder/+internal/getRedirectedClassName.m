function redirectedClass = getRedirectedClassName(className)
    arguments
        className char
    end
    % getRedirectedClassName gets the output of static function matlabCodegenRedirect
    % for class "className".

    % Copyright 2016-2022 The MathWorks, Inc.

    if strcmp(className, 'string')
        redirectedClass = 'coder.internal.string';
    else
        narginCheck(className, 'matlabCodegenRedirect');
        try
            % We need to call matlabCodegenRedirect without searching parent classes, because
            % class redirection should not be inherited from base classes. We only want to call
            % the method if it exists on the derived class itself.
            redirectedClass = coder.internal.callMATLABCodegenStaticMethod(className, 'matlabCodegenRedirect', ...
                coder.target, SearchParentClasses = false);
        catch
            redirectedClass = className;
        end
    end
end

function narginCheck(className, methodName)
    if coder.internal.hasStaticMethod(className, methodName, SearchParentClasses=false)
        f = eval(['@' className '.' methodName]);
        if ~nargin(f)
            error(message('Coder:common:MatlabCodegenRedirectMustAcceptOneInput', className));
        end
    end
end
