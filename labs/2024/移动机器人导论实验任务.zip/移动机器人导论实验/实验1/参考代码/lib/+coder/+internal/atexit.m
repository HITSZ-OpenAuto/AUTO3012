function atexit(varargin)
%

%   Copyright 2013-2020 The MathWorks, Inc.
