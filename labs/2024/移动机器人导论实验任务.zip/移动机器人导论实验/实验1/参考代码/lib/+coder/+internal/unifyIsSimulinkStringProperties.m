function unifyIsSimulinkStringProperties(varargin)
%MATLAB Code Generation Private Function

%   Copyright 2019 The MathWorks, Inc.
