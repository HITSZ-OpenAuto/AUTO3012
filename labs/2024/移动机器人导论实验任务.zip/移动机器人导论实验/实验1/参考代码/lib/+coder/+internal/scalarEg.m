function x = scalarEg(varargin)
%

% Copyright 2019 The MathWorks, Inc.
%
% This implementation is used in MATLAB execution only.
% In code generation, coder.internal.scalarEg is a built-in.
x = coder.internal.scalarEgImpl(varargin{:});
