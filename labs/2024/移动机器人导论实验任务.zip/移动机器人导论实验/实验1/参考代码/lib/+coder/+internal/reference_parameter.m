function reference_parameter(~)
%MATLAB Code Generation Private Function

%   Copyright 2018-2019 The MathWorks, Inc.
end
