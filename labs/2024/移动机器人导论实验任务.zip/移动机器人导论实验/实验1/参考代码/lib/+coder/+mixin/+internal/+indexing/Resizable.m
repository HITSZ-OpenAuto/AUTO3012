classdef (Abstract, HandleCompatible) Resizable
% Coder-specific Resizable implementation

%   Copyright 2022 The Math Works, Inc.
%#codegen
end
