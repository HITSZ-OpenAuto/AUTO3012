function prefer_const(varargin)
%

%   Copyright 2010-2019 The MathWorks, Inc.

end
