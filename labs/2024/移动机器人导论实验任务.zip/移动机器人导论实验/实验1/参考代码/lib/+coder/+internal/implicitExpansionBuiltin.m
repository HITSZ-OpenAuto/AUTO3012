function implicitExpansionBuiltin
%MATLAB Code Generation Private Function

%   Copyright 2020 The MathWorks, Inc.