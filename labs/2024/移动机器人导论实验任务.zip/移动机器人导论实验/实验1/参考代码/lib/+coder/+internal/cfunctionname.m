function cfunctionname(~)
% MATLAB Code generation private function.

%  Copyright 2007-2019 The MathWorks, Inc.

