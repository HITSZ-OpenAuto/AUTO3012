function y = ifConstantFoldingThenElse(~,y)
%MATLAB Code Generation Private Function

% MATLAB execution for Coder built-in function
%   Copyright 2017-2019 The MathWorks, Inc.

