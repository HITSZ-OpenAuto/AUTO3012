function y = indexInt(x)%
%

%   Copyright 2011-2019 The MathWorks, Inc.

y = cast(x,coder.internal.indexIntClass);
