function mustBeConst(x)
%CODER.MUSTBECONST Validate that value is a compile-time constant
%   CODER.MUSTBECONST(X) throws an error during code generation if X
%   is not a compile-time constant.
%   This validator has no effect in MATLAB execution.

%#codegen
if ~isempty(coder.target)
    narginchk(1, 1);
    coder.internal.allowEnumInputs;
    coder.internal.allowHalfInputs;
    eml_allow_mx_inputs;
    coder.internal.prefer_const(x);
    coder.internal.assert(coder.internal.isConst(x), 'Coder:builtins:MustBeConst');
end
