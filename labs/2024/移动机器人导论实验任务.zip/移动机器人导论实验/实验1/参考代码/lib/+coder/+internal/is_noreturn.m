function is_noreturn
%

%   Copyright 2011-2019 The MathWorks, Inc.

end
