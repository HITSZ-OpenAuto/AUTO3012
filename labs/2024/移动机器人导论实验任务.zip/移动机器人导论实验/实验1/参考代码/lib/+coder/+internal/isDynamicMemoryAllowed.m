function b = isDynamicMemoryAllowed()
%MATLAB Code Generation Private Function

% Return true if an dynamic memory allocation is allowed, false otherwise.

%   Copyright 2022 The MathWorks, Inc.
%#codegen
coder.inline('always');
mallocOpt = eml_option('UseMalloc');
b = coder.const(strcmpi(mallocOpt, "VariableSizeArrays"));